The following files were generated for 'div_gen_v3_0' in directory
D:\MYPROGS\FPGA\XILINX\PROJECTS\test_centroid1\ipcore_dir\

XCO file generator:
   Generate an XCO file for compatibility with legacy flows.

   * div_gen_v3_0.xco

Creates an implementation netlist:
   Creates an implementation netlist for the IP.

   * div_gen_v3_0.ngc
   * div_gen_v3_0.v
   * div_gen_v3_0.veo

Creates an HDL instantiation template:
   Creates an HDL instantiation template for the IP.

   * div_gen_v3_0.veo

IP Symbol Generator:
   Generate an IP symbol based on the current project options'.

   * div_gen_v3_0.asy

Generate ISE metadata:
   Create a metadata file for use when including this core in ISE designs

   * div_gen_v3_0_xmdf.tcl

Generate ISE subproject:
   Create an ISE subproject for use when including this core in ISE designs

   * _xmsgs/pn_parser.xmsgs
   * div_gen_v3_0.gise
   * div_gen_v3_0.xise

Deliver Readme:
   Readme file for the IP.

   * div_gen_v3_0_readme.txt

Generate FLIST file:
   Text file listing all of the output files produced when a customized core was
   generated in the CORE Generator.

   * div_gen_v3_0_flist.txt

Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

